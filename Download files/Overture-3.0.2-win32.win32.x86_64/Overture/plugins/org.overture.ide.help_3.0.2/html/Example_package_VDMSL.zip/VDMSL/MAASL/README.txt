Author: Graeme Parkin


This specification is of the Message Authenticator Algorithm (MAA)
standard is used in the area of data security in banking and the scope
of the standard is authentication. More details can be found in:

G.I. Parkin and G O'Neill, "Specification of the MAA standard in
VDM'', In S. Prehn and W.J. Toetenel (eds), "VDM'91: Formal Software
Development Methods'', Springer-Verlag, October 1991.



Language Version: classic