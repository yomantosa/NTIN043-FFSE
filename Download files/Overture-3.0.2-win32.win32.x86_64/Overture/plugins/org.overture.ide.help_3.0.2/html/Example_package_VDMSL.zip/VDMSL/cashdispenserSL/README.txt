Author: Peter Gorm Larsen


This model is described in VDM-SL as a very abstract specification
of how a pacemaker can pace a heart that is not having periodic 
stroken in the two heart chambers. 

Language Version: vdm10
Entry point     : DEFAULT`Sum([1,2,3,4,5,6,7,8,9])