Author: Peter Gorm Larsen and John Fitzgerald


This example is for all small traffic light control kernel presented in the VDM-SL book
of John Fitzgerald and Peter Gorm Larsen. It was originally inspired by a similar model
made in Z by Paul Ammann. A paper about this written long ago:
 
A safety kernel for traffic light control, Paul Ammann, Aerospace and Electronic 
Systems Magazine, IEEE, February 1996, Volume: 11 Issue: 2, pp. 13 - 19, 
ISSN: 0885-8985. 


Language Version: classic
Entry point     : DEFAULT`ToAmber(p3,kernel)