Author: John Fitzgerald and Peter Gorm Larsen


This example is used to illustrate the difference between different
formal approaches in the Alloy book. The example models a scheme
for recodable hotel-door locks. More information can be found in:

Daniel Jackson, Software Abstractions, MIT Press, April 2006
ISBN 0-262-10114-9.


Language Version: classic