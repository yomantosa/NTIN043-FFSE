Author: Quentin Charatan and Aaron Kans


This example comes from the book "Formal Software Development: From VDM to Java" written by Quentin Charatan and Aaron Kans. This example illustrate how to model bank accounts and transactions made on these as a series of deposits and withdrawals.


Language Version: vdm10
Entry point     : DEFAULT`sum([1,2,3,4,5,6,7,8,9])