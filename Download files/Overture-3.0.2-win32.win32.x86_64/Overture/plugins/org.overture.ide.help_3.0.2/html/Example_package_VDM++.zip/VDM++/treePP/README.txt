Author: 



This VDM++ model contains basic classes for defining 
and traversing over abstract threes and queues.
 

Language Version: vdm10