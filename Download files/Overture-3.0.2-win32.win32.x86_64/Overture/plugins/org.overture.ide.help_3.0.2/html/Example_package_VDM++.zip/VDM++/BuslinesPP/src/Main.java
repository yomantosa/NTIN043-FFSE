
import org.overture.interpreter.values.IntegerValue;
import org.overture.interpreter.values.SeqValue;

import gui.Graphics;

public class Main {

    /**
     * @param args the command line arguments
     * @throws Exception 
     * @throws ValueException 
     */
    public static void main(String[] args) throws Exception {
        //Controller ctrl = new Controller();
    	Graphics g = new Graphics();
    	g.init();
    	
    	g.busAdded(new IntegerValue(1));
    	g.busAdded(new IntegerValue(2));
    	
    	g.busPassengerCountChanged(new IntegerValue(1), new IntegerValue(10));
    	g.busPassengerCountChanged(new IntegerValue(1), new IntegerValue(4));
    	
//    	int i = 0;
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerGotOnBus(new IntegerValue(1));
//    	g.sleep();
//    	g.passengerGotOnBus(new IntegerValue(2));
//    	g.passengerGotOnBus(new IntegerValue(4));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerGotOnBus(new IntegerValue(8));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.passengerAtCentral(new IntegerValue(i++));
//    	g.sleep();
//    	g.passengerAnnoyed(new IntegerValue(5));
//    	g.passengerAnnoyed(new IntegerValue(7));
//    	g.passengerGotOnBus(new IntegerValue(15));
//    	g.passengerGotOnBus(new IntegerValue(12));
//    	g.passengerGotOnBus(new IntegerValue(13));
//    	g.passengerAnnoyed(new IntegerValue(10));
//    	g.sleep();
//    	g.passengerGotOnBus(new IntegerValue(11));
//    	g.sleep();
//    	g.passengerGotOnBus(new IntegerValue(10));
//      	g.passengerAtCentral(new IntegerValue(i++));
//      	g.passengerAtCentral(new IntegerValue(i++));
//      	
//      	g.inflowChanged(new IntegerValue(1));
//      	g.sleep();
//    	g.inflowChanged(new IntegerValue(4));
//      	g.sleep();
//    	g.inflowChanged(new IntegerValue(2));
//      	g.sleep();
//    	g.inflowChanged(new IntegerValue(8));
    	
    	g.busInRouteTo(new IntegerValue(2), new SeqValue("<R9>"), new SeqValue("<WP3>"), new IntegerValue(5));
    	g.busInRouteTo(new IntegerValue(1), new SeqValue("<R8>"), new SeqValue("<F>"), new IntegerValue(5));
    	g.move();
    	g.sleep();
    	g.move();
    	g.sleep();
    	g.move();
    	g.sleep();
    	g.move();
    	g.sleep();
    	g.move();
    	g.sleep();
    	g.busInRouteTo(new IntegerValue(2), new SeqValue("R10"), new SeqValue("WP4"), new IntegerValue(3));
    	g.busInRouteTo(new IntegerValue(1), new SeqValue("<R15>"), new SeqValue("<WP4>"), new IntegerValue(5));
       	g.move();
    	g.sleep();
    	g.move();
    	g.sleep();
    	g.move();
      	g.sleep();
    	g.move();
    	g.busInRouteTo(new IntegerValue(2), new SeqValue("R15"), new SeqValue("F"), new IntegerValue(2));
       	g.move();
    	g.sleep();
    	g.move();
    	g.sleep();
    	g.move();
    	g.busStopping(new IntegerValue(2));
    	g.busInRouteTo(new IntegerValue(2), new SeqValue("R8"), new SeqValue("Central"), new IntegerValue(10));
    	g.busInRouteTo(new IntegerValue(1), new SeqValue("<R10>"), new SeqValue("<WP3>"), new IntegerValue(5));
    	for (int i = 0; i < 11; i++) {
         	g.move();
        	g.sleep();
		}
    	g.busInRouteTo(new IntegerValue(2), new SeqValue("HW1"), new SeqValue("A"), new IntegerValue(31));
    	for (int i = 0; i < 32; i++) {
         	g.move();
        	g.sleep();
		}
    	
    }	
}
