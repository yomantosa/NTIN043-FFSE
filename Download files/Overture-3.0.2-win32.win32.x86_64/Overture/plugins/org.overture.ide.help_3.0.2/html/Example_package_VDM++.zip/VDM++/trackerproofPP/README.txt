Author: John Fitzgerald



This VDM++ model is a direct transformation from the 
VDM-SL model presented in the Fitzgerald&Larsen98 book 
on VDM-SL. The tracker takes care of monitoring and 
controlling the nuclear material in a plant that takes 
care of processing such waste material. 


Language Version: vdm10