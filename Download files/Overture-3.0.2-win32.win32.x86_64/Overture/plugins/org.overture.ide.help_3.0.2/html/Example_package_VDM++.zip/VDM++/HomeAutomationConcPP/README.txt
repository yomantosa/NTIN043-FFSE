Author: Sune Wolff




Language Version: vdm10
Entry point     : new World().Run()