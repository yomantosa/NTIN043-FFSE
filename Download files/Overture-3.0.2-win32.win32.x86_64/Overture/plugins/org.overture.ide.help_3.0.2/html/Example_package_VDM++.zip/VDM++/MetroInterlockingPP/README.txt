Author: Steffen Diswal


This example is produced by a student as a part of a VDM course given at the Department of Engineering at the University of Aarhus. This model describes a small interlocking system for a metro.  

Language Version: vdm10
Entry point     : new World().Run(18)
Entry point     : new UnitTestRunner().Execute()