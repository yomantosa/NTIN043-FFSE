Author: Peter Gorm Larsen


This VDM++ model is made by Peter Gorm Larsen in 2010 based on the original 
VDM++ model created many years ago at IFAD.


Language Version: vdm10
Entry point     : new SortMachine().GoSorting([4,2,5,6,4,42,1,1,99,5])