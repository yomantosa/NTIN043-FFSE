Author: 



This is a very simple VDM++ of the basic functionality of a web
server.


Language Version: vdm10