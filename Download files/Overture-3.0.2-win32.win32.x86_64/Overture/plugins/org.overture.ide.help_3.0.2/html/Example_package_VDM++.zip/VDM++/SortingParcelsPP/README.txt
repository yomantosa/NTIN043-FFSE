Author: Bjarke Møholt


The purpose of this VDM++ model is to analyse the rules governing for
distributing parcels with different kinds of goods is a
warehouse. This model is made by Bjarke Møholt as a small mini-project
in a course on "Modelling of Mission Critical Systems" (see
https://services.brics.dk/java/courseadmin/TOMoMi/pages/Modelling+of+Mission+Critical+Systems).


Language Version: vdm10
Entry point     : new Test().Run()