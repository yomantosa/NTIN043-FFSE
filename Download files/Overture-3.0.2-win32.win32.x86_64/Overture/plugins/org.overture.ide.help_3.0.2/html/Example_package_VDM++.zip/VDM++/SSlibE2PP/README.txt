Author: Shin Sahara


This example contains a large collection of test classes that can be
used to test different aspects of VDM++. This makes use of the VDMUnit 
test approach.


Language Version: classic
Entry point     : new AllT().run()