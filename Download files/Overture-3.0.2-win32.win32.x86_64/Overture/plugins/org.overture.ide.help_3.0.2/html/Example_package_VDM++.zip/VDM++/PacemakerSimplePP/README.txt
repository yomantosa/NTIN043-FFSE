Author: Steve Riddle and Peter Gorm Larsen


This model is a very simple version of the pacemaker as it has
been used for a small exercise to VDM newcommers. It was first 
used in a VDM course delivered by Steve Riddle and John Fitzgerald
and later used and adjusted by Peter Gorm Larsen also. 


Language Version: classic
Entry point     : new Heart().IdealHeart()
Entry point     : new Pacemaker().Pace(Pacemaker`wrongTR,5,2)