Author: Nick Battle


This example is a simple Sorting library with tests that are partly formed from combinatorial traces,
and partly from VDMUnit tests.


Language Version: vdm10
Entry point     : new TestAll().Run()