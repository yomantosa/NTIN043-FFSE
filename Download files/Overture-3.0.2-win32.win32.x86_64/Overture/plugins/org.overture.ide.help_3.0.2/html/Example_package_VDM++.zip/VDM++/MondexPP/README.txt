Author: 




Language Version: classic
Entry point     : new AbPurseFunctional().RunTest()