Author: Marcel Verhoef


This was the first model Marcel Verhoef tried to make of the car
radio navigation example using the original version of VICE with
one CPU. This failed and as a consequence Marcel Verhoef and Peter
Gorm Larsen came up with an improved version of VDM-RT with 
multiple CPUs connected with BUSses.


Language Version: vdm10
Entry point     : new RadNavSys(1).Run()
Entry point     : new RadNavSys(2).Run()